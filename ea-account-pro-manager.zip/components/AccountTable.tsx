
import React from 'react';
import { Account } from '../types';

interface AccountTableProps {
  accounts: Account[];
  isAdmin: boolean;
  onRemove?: (account: string) => void;
}

export const AccountTable: React.FC<AccountTableProps> = ({ accounts, isAdmin, onRemove }) => {
  const isNearExpiry = (expireDate: string) => {
    const today = new Date();
    const expiry = new Date(expireDate);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 3;
  };

  return (
    <div className="w-full overflow-hidden rounded-xl border border-slate-800 bg-slate-900/50">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-800/50">
              <th className="px-6 py-4 text-slate-400 font-semibold text-sm">Account</th>
              <th className="px-6 py-4 text-slate-400 font-semibold text-sm">Expire Date</th>
              <th className="px-6 py-4 text-slate-400 font-semibold text-sm">Status</th>
              <th className="px-6 py-4 text-slate-400 font-semibold text-sm">Package</th>
              {isAdmin && <th className="px-6 py-4 text-slate-400 font-semibold text-sm">History</th>}
              {isAdmin && <th className="px-6 py-4 text-slate-400 font-semibold text-sm text-right">Actions</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {accounts.length === 0 ? (
              <tr>
                <td colSpan={isAdmin ? 6 : 4} className="px-6 py-12 text-center text-slate-500">
                  No accounts found in system.
                </td>
              </tr>
            ) : (
              accounts.map((acc) => {
                const expiring = isNearExpiry(acc.expire);
                return (
                  <tr 
                    key={acc.account} 
                    className={`transition-colors hover:bg-slate-800/30 ${
                      expiring ? 'bg-amber-900/20' : ''
                    }`}
                  >
                    <td className="px-6 py-4 font-medium text-slate-200">{acc.account}</td>
                    <td className="px-6 py-4">
                      <span className={`${expiring ? 'text-amber-400 font-semibold' : 'text-slate-300'}`}>
                        {acc.expire}
                        {expiring && <span className="ml-2 text-[10px] uppercase bg-amber-500/20 px-2 py-0.5 rounded">Alert</span>}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        acc.status === 'active' 
                          ? 'bg-emerald-500/10 text-emerald-400' 
                          : 'bg-rose-500/10 text-rose-400'
                      }`}>
                        {acc.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-slate-300 font-mono">{acc.package}</td>
                    {isAdmin && (
                      <td className="px-6 py-4">
                        <div className="max-w-[200px] max-h-[60px] overflow-y-auto scrollbar-hide text-[11px] text-slate-400 space-y-1">
                          {acc.history.length > 0 ? (
                            acc.history.map((h, i) => (
                              <div key={i} className="border-l border-slate-700 pl-2">
                                {h.date}: {h.package} (+{h.added})
                              </div>
                            ))
                          ) : '-'}
                        </div>
                      </td>
                    )}
                    {isAdmin && (
                      <td className="px-6 py-4 text-right">
                        <button 
                          onClick={() => onRemove?.(acc.account)}
                          className="text-rose-400 hover:text-rose-300 transition-colors p-2 hover:bg-rose-500/10 rounded-lg"
                          title="Remove Account"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
