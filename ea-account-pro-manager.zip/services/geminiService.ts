
import { GoogleGenAI } from "@google/genai";
import { Account } from "../types";

export const getAccountAudit = async (accounts: Account[]) => {
  if (!process.env.API_KEY) return "AI Insights unavailable: API Key not configured.";

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following account data and provide a brief executive summary (max 3 sentences) focusing on revenue trends and potential retention issues. Data: ${JSON.stringify(accounts)}`,
    config: {
      temperature: 0.7,
      maxOutputTokens: 200,
    }
  });

  try {
    const result = await model;
    return result.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error generating AI audit.";
  }
};
